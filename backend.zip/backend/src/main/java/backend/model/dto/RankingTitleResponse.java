package backend.model.dto;

import lombok.Data;

@Data
public class RankingTitleResponse {
    private int rankingTitleId;
    private String titleName;
}
