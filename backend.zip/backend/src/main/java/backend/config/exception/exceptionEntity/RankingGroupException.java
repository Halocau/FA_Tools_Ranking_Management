package backend.config.exception.exceptionEntity;

public class RankingGroupException extends RuntimeException {
    public RankingGroupException(String message) {
        super(message);
    }
}