package backend.config.exception;

public class RankingGroupException extends RuntimeException {
    public RankingGroupException(String message) {
        super(message);
    }
}