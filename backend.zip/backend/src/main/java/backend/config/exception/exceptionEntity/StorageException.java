package backend.config.exception.exceptionEntity;

public class StorageException extends Exception {
    public StorageException(String message) {
        super(message);
    }
}
