package backend.config.exception.exceptionEntity;

public class TaskException extends RuntimeException {
    public TaskException(String message) {
        super(message);
    }
}
