package backend.config.exception.exceptionEntity;

public class PageException extends RuntimeException {
    public PageException(String message) {
        super(message);
    }
}
