package backend.config.exception.exceptionEntity;

public class AccountException extends RuntimeException {
    public AccountException(String message) {
        super(message);
    }
}
